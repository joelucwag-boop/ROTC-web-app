# ROTC Web App (Availability + Attendance + Reports)

See `.env.example` for env vars. Start command:
```
gunicorn app:app
```
Open: `https://YOUR.onrender.com/?pw=YOUR_PASSWORD`.
